from ccode.patching import touched_files_from_patch

def test_touched_files_from_patch_git_style():
    patch = """diff --git a/foo.txt b/foo.txt
index 111..222 100644
--- a/foo.txt
+++ b/foo.txt
@@ -1 +1 @@
-hello
+world
"""
    assert touched_files_from_patch(patch) == {"foo.txt"}
