# ccode

`ccode` is a **Claude Code–like** command-line coding assistant that operates on a **local workspace folder**, supports **interactive back-and-forth**, and can **delegate work to sub-agents** (planner/coder/reviewer/etc.). It is designed to use your **custom Agno model library** via a small adapter.

## Quick start

```bash
# from the repo root you want to work on
python -m pip install -e .

ccode init
ccode chat
```

### Configure your Agno model

The *primary* place to select the model is:

- **`.ccode/config.toml`** → `[model] name = "..."`

If your Agno library needs custom wiring, update:

- **`src/ccode/llm/agno_provider.py`** (this is the adapter layer)

## CLI

- `ccode init` – creates `.ccode/config.toml`
- `ccode chat` – interactive REPL
- `ccode run "prompt..."` – one-shot (non-interactive) run

## REPL commands (inside `ccode chat`)

- `/help` – show commands
- `/tree` – show a truncated file tree
- `/add path/to/file.py` – add file to context
- `/drop path/to/file.py` – remove file from context
- `/open path/to/file.py` – view file
- `/search "pattern"` – grep-like search
- `/agent planner|coder|reviewer|general` – switch active agent
- `/delegate coder implement X` – run a sub-agent and return its result
- `/auto implement X` – planner→coder→reviewer pipeline
- `/status` – show git status
- `/diff` – show pending patches proposed by the model
- `/apply [n]` – apply all pending patches or the nth patch
- `/undo` – undo last apply (restores backups)
- `/run make test` – run a shell command (asks for confirmation)
- `/save` – save session to `.ccode/sessions/`
- `/exit` – exit

## How edits work

The model proposes edits as a **unified diff** inside a `<patch>...</patch>` block.
`ccode` stores patches as **pending** until you apply them.

This makes the tool safer and easier to audit vs. “auto-write files without review”.

## Notes

- The workspace is sandboxed: file reads/writes are restricted to the chosen root folder.
- For large repos, add patterns to `.ccodeignore` to keep indexing quick.
