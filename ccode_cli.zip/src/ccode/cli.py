from __future__ import annotations

from pathlib import Path
import typer
from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown

from .config import init_workspace_config, load_config, workspace_config_path
from .repl import run_chat
from .workspace import Workspace
from .agents.manager import AgentManager
from .llm.provider import DummyProvider
from .llm.agno_provider import AgnoProvider
from .orchestrator import Orchestrator
from .session import SessionState, save_session, load_session


app = typer.Typer(add_completion=False)


def _make_provider(cfg):
    if cfg.model.provider == "dummy":
        return DummyProvider()
    if cfg.model.provider == "agno":
        return AgnoProvider(cfg.model)
    raise typer.BadParameter(f"Unknown model provider: {cfg.model.provider}")


@app.command()
def init(
    root: Path = typer.Option(Path("."), "--root", "-r", help="Workspace root (defaults to current directory)."),
    overwrite: bool = typer.Option(False, "--overwrite", help="Overwrite existing .ccode/config.toml"),
):
    """Initialize .ccode/config.toml in the workspace."""
    root = root.resolve()
    path = init_workspace_config(root, overwrite=overwrite)
    Console().print(Panel.fit(f"Initialized config at {path}", title="ccode init"))


@app.command()
def chat(
    root: Path = typer.Option(Path("."), "--root", "-r", help="Workspace root (defaults to current directory)."),
    session: str | None = typer.Option(None, "--session", "-s", help="Load an existing session id."),
):
    """Start an interactive chat session."""
    run_chat(root, session_id=session)


@app.command()
def run(
    prompt: str = typer.Argument(..., help="User prompt to run once (non-interactive)."),
    root: Path = typer.Option(Path("."), "--root", "-r", help="Workspace root (defaults to current directory)."),
    agent: str | None = typer.Option(None, "--agent", help="Agent to use (general/planner/coder/reviewer)."),
):
    """Run a single turn (non-interactive)."""
    console = Console()
    root = root.resolve()
    if not workspace_config_path(root).exists():
        init_workspace_config(root, overwrite=False)
        console.print("Created .ccode/config.toml (edit it to set your model).")
    cfg = load_config(root)
    ws = Workspace.from_root(root)
    agents = AgentManager(cfg.agents.enabled, cfg.agents.default)
    provider = _make_provider(cfg)
    orch = Orchestrator(ws, cfg, provider, agents)

    session_state = SessionState.new(root, active_agent=agent or agents.default)
    session_state.messages.append({"role": "user", "content": prompt})

    # In non-interactive mode, disallow approval-required tools.
    def approve(tool_name, args):
        return False

    res = orch.run_turn(session_state, agent_name=agent, approval_fn=approve, max_steps=6)
    if res.assistant_text:
        console.print(Markdown(res.assistant_text))
    if res.new_patches:
        console.print(Panel.fit(f"{len(res.new_patches)} patch(es) proposed (not applied). Run ccode chat to review/apply.", title="Patches"))
    save_session(root, session_state)
    console.print(f"Session saved: {session_state.id}")
