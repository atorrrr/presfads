from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List

from .provider import LLMProvider, Message
from ..config import ModelConfig

# NOTE:
# This file is intentionally small and easy to modify.
# It is the ONLY place you should need to change if your Agno library's API differs.
#
# You can also set the model in .ccode/config.toml:
#   [model]
#   name = "YOUR_MODEL"
#
# If your Agno library requires a different constructor or call pattern,
# edit AgnoProvider.__init__ and AgnoProvider.chat below.

try:
    import agno  # type: ignore
except Exception:  # pragma: no cover
    agno = None


class AgnoProvider(LLMProvider):
    def __init__(self, cfg: ModelConfig):
        if agno is None:
            raise RuntimeError(
                "Agno library not found. Install your custom agno package, or set "
                "[model] provider='dummy' in .ccode/config.toml for offline mode."
            )
        self.cfg = cfg

        # TODO: Wire up your Agno agent/model here.
        #
        # Common patterns (examples only):
        #   self.client = agno.Client(...)
        #   self.agent = agno.Agent(model=cfg.name, temperature=cfg.temperature, ...)
        #
        # The only requirement is that .chat() returns a string response.

        if hasattr(agno, "Agent"):
            # best-effort guess: agno.Agent exists
            self.agent = agno.Agent(  # type: ignore
                model=cfg.name,
                temperature=cfg.temperature,
                max_tokens=cfg.max_tokens,
                **(cfg.extra or {}),
            )
        else:
            self.agent = None

    def chat(self, *, system_prompt: str, messages: List[Message], tools: list[dict] | None = None) -> str:
        # TODO: Map ccode's (system_prompt, messages, tools) into your Agno API.
        #
        # If your Agno library supports tool/function calling, you can pass `tools`.
        # If not, ignore tools; ccode uses a tag-based protocol (see prompts) that works without native tools.
        if self.agent is None:
            raise RuntimeError("AgnoProvider not configured: couldn't find agno.Agent. Edit src/ccode/llm/agno_provider.py.")

        # Best-effort guess: agent.chat(...) exists and accepts system + messages
        if hasattr(self.agent, "chat"):
            return self.agent.chat(system=system_prompt, messages=messages, tools=tools)  # type: ignore

        # Alternative guess: agent.run(...) returns text
        if hasattr(self.agent, "run"):
            return self.agent.run(system_prompt=system_prompt, messages=messages, tools=tools)  # type: ignore

        raise RuntimeError("Unsupported Agno agent API. Edit src/ccode/llm/agno_provider.py to adapt to your library.")
