from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, List, Optional


Message = Dict[str, str]


class LLMProvider(ABC):
    @abstractmethod
    def chat(self, *, system_prompt: str, messages: List[Message], tools: list[dict] | None = None) -> str:
        """Return the assistant text."""
        raise NotImplementedError


@dataclass
class DummyProvider(LLMProvider):
    """Offline provider useful for smoke testing the CLI."""
    def chat(self, *, system_prompt: str, messages: List[Message], tools: list[dict] | None = None) -> str:
        last_user = next((m["content"] for m in reversed(messages) if m.get("role") == "user"), "")
        return (
            "I am the dummy provider (no LLM configured).\n\n"
            f"You said: {last_user}\n\n"
            "Tip: set [model] provider='agno' and configure your model name in .ccode/config.toml."
        )
