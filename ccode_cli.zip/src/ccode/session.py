from __future__ import annotations

from dataclasses import dataclass, field, asdict
from pathlib import Path
import json
import time
import uuid
from typing import Any, Dict, List, Optional


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


@dataclass
class PendingPatch:
    id: str
    created_at: str
    agent: str
    summary: str
    patch: str


@dataclass
class SessionState:
    id: str
    created_at: str
    workspace_root: str
    active_agent: str = "general"
    selected_files: list[str] = field(default_factory=list)
    messages: list[dict] = field(default_factory=list)  # [{role, content, ...}]
    pending_patches: list[PendingPatch] = field(default_factory=list)
    last_backup_dir: str | None = None

    @staticmethod
    def new(workspace_root: Path, active_agent: str = "general") -> "SessionState":
        sid = uuid.uuid4().hex[:12]
        return SessionState(
            id=sid,
            created_at=_now_iso(),
            workspace_root=str(workspace_root),
            active_agent=active_agent,
        )

    def to_json(self) -> str:
        d = asdict(self)
        # pending patches are dataclasses; ensure plain
        return json.dumps(d, indent=2, ensure_ascii=False)

    @staticmethod
    def from_json(text: str) -> "SessionState":
        d = json.loads(text)
        patches = [PendingPatch(**p) for p in d.get("pending_patches", [])]
        s = SessionState(
            id=d["id"],
            created_at=d.get("created_at", _now_iso()),
            workspace_root=d["workspace_root"],
            active_agent=d.get("active_agent", "general"),
            selected_files=d.get("selected_files", []),
            messages=d.get("messages", []),
            pending_patches=patches,
            last_backup_dir=d.get("last_backup_dir"),
        )
        return s


def sessions_dir(root: Path) -> Path:
    return root / ".ccode" / "sessions"


def save_session(root: Path, session: SessionState) -> Path:
    d = sessions_dir(root)
    d.mkdir(parents=True, exist_ok=True)
    path = d / f"{session.id}.json"
    path.write_text(session.to_json(), encoding="utf-8")
    return path


def load_session(root: Path, session_id: str) -> SessionState:
    path = sessions_dir(root) / f"{session_id}.json"
    if not path.exists():
        raise FileNotFoundError(f"Session not found: {path}")
    return SessionState.from_json(path.read_text(encoding="utf-8"))


def list_sessions(root: Path) -> list[str]:
    d = sessions_dir(root)
    if not d.exists():
        return []
    out = []
    for p in sorted(d.glob("*.json")):
        out.append(p.stem)
    return out
