from __future__ import annotations

from dataclasses import dataclass
import json
import shutil
import subprocess
from typing import Any, Callable, Dict

from .workspace import Workspace


@dataclass
class ToolSpec:
    name: str
    description: str
    requires_approval: bool = False


ToolFn = Callable[[Dict[str, Any]], Any]


class ToolRegistry:
    def __init__(self) -> None:
        self._specs: Dict[str, ToolSpec] = {}
        self._fns: Dict[str, ToolFn] = {}

    def register(self, spec: ToolSpec, fn: ToolFn) -> None:
        self._specs[spec.name] = spec
        self._fns[spec.name] = fn

    def spec(self, name: str) -> ToolSpec | None:
        return self._specs.get(name)

    def call(self, name: str, args: Dict[str, Any]) -> Any:
        if name not in self._fns:
            raise KeyError(f"Unknown tool: {name}")
        return self._fns[name](args)

    def list_specs(self) -> list[ToolSpec]:
        return list(self._specs.values())


def build_default_tools(
    workspace: Workspace,
    *,
    run_command_fn: Callable[[str], dict],
    delegate_fn: Callable[[str, str], str],
) -> ToolRegistry:
    reg = ToolRegistry()

    def list_files(args: Dict[str, Any]) -> Any:
        limit = int(args.get("limit", 200))
        return {"files": workspace.list_files(limit=limit)}

    def file_tree(args: Dict[str, Any]) -> Any:
        max_entries = int(args.get("max_entries", 200))
        return {"tree": workspace.tree(max_entries=max_entries)}

    def read_file(args: Dict[str, Any]) -> Any:
        path = str(args["path"])
        start_line = args.get("start_line")
        end_line = args.get("end_line")
        text = workspace.read_text(path, max_bytes=400_000)
        lines = text.splitlines()
        if start_line is not None or end_line is not None:
            s = max(1, int(start_line or 1))
            e = min(len(lines), int(end_line or len(lines)))
            snippet = "\n".join(lines[s-1:e])
        else:
            # default cap
            snippet = "\n".join(lines[:400])
            if len(lines) > 400:
                snippet += f"\n... (truncated; total lines: {len(lines)})"
        return {"path": path, "content": snippet}

    def search(args: Dict[str, Any]) -> Any:
        query = str(args["query"])
        glob = args.get("glob")
        max_results = int(args.get("max_results", 20))
        return {"query": query, "results": workspace.search(query, glob=glob, max_results=max_results)}

    def git_status(args: Dict[str, Any]) -> Any:
        git = shutil.which("git")
        if not git:
            return {"error": "git not found"}
        try:
            proc = subprocess.run(
                [git, "status", "--porcelain=v1", "-b"],
                cwd=str(workspace.root),
                capture_output=True,
                text=True,
                timeout=10,
            )
            return {"returncode": proc.returncode, "stdout": (proc.stdout or "")[-8000:], "stderr": (proc.stderr or "")[-2000:]}
        except Exception as e:
            return {"error": str(e)}

    def git_diff(args: Dict[str, Any]) -> Any:
        git = shutil.which("git")
        if not git:
            return {"error": "git not found"}
        path = args.get("path")
        try:
            cmd = [git, "diff"]
            if path:
                cmd += ["--", str(path)]
            proc = subprocess.run(
                cmd,
                cwd=str(workspace.root),
                capture_output=True,
                text=True,
                timeout=10,
            )
            return {"returncode": proc.returncode, "stdout": (proc.stdout or "")[-12000:], "stderr": (proc.stderr or "")[-2000:]}
        except Exception as e:
            return {"error": str(e)}

    def run_command(args: Dict[str, Any]) -> Any:
        cmd = str(args["cmd"])
        return run_command_fn(cmd)

    def delegate(args: Dict[str, Any]) -> Any:
        agent = str(args["agent"])
        task = str(args["task"])
        text = delegate_fn(agent, task)
        return {"agent": agent, "task": task, "output": text}

    reg.register(ToolSpec("list_files", "List files in the workspace. Args: {limit:int}"), list_files)
    reg.register(ToolSpec("file_tree", "Return a truncated file tree. Args: {max_entries?:int}"), file_tree)
    reg.register(ToolSpec("read_file", "Read a text file. Args: {path:str, start_line?:int, end_line?:int}"), read_file)
    reg.register(ToolSpec("search", "Search for a string in the workspace. Args: {query:str, glob?:str, max_results?:int}"), search)
    reg.register(ToolSpec("git_status", "Show git status (porcelain). No args."), git_status)
    reg.register(ToolSpec("git_diff", "Show git diff (truncated). Args: {path?:str}"), git_diff)
    reg.register(ToolSpec("run_command", "Run a shell command in the workspace. Args: {cmd:str}", requires_approval=True), run_command)
    reg.register(ToolSpec("delegate", "Delegate a task to a sub-agent. Args: {agent:str, task:str}"), delegate)
    return reg
