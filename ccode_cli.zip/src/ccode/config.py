from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import os
import tomllib
from typing import Any, Dict, Optional


DEFAULT_CONFIG_TOML = """[model]
# provider: "agno" (your custom library) or "dummy" (offline echo provider)
provider = "agno"
# The model identifier passed to your Agno library
name = "YOUR_AGNO_MODEL_NAME"
temperature = 0.2
max_tokens = 4096

[runtime]
# Ask before applying patches / running commands
confirm_writes = true
confirm_commands = true

# Rough cap on how much file context is injected per turn (characters)
context_max_chars = 120000

[agents]
# Built-in agents available in the REPL
enabled = ["general", "planner", "coder", "reviewer"]
default = "general"
"""


@dataclass
class ModelConfig:
    provider: str = "agno"
    name: str = "YOUR_AGNO_MODEL_NAME"
    temperature: float = 0.2
    max_tokens: int = 4096
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RuntimeConfig:
    confirm_writes: bool = True
    confirm_commands: bool = True
    context_max_chars: int = 120000


@dataclass
class AgentsConfig:
    enabled: list[str] = field(default_factory=lambda: ["general", "planner", "coder", "reviewer"])
    default: str = "general"


@dataclass
class AppConfig:
    model: ModelConfig = field(default_factory=ModelConfig)
    runtime: RuntimeConfig = field(default_factory=RuntimeConfig)
    agents: AgentsConfig = field(default_factory=AgentsConfig)

    @staticmethod
    def from_toml_dict(d: dict) -> "AppConfig":
        model_d = d.get("model", {}) or {}
        runtime_d = d.get("runtime", {}) or {}
        agents_d = d.get("agents", {}) or {}

        model = ModelConfig(
            provider=str(model_d.get("provider", "agno")),
            name=str(model_d.get("name", "YOUR_AGNO_MODEL_NAME")),
            temperature=float(model_d.get("temperature", 0.2)),
            max_tokens=int(model_d.get("max_tokens", 4096)),
            extra={k: v for k, v in model_d.items() if k not in {"provider", "name", "temperature", "max_tokens"}},
        )
        runtime = RuntimeConfig(
            confirm_writes=bool(runtime_d.get("confirm_writes", True)),
            confirm_commands=bool(runtime_d.get("confirm_commands", True)),
            context_max_chars=int(runtime_d.get("context_max_chars", 120000)),
        )
        agents = AgentsConfig(
            enabled=list(agents_d.get("enabled", ["general", "planner", "coder", "reviewer"])),
            default=str(agents_d.get("default", "general")),
        )
        return AppConfig(model=model, runtime=runtime, agents=agents)


def workspace_config_path(root: Path) -> Path:
    return root / ".ccode" / "config.toml"


def global_config_path() -> Path:
    xdg = os.environ.get("XDG_CONFIG_HOME")
    base = Path(xdg) if xdg else Path.home() / ".config"
    return base / "ccode" / "config.toml"


def load_config(workspace_root: Path) -> AppConfig:
    """Loads config from workspace, falling back to global, then defaults."""
    ws_path = workspace_config_path(workspace_root)
    gl_path = global_config_path()

    data: dict | None = None
    if ws_path.exists():
        data = tomllib.loads(ws_path.read_text(encoding="utf-8"))
    elif gl_path.exists():
        data = tomllib.loads(gl_path.read_text(encoding="utf-8"))

    if not data:
        return AppConfig()

    return AppConfig.from_toml_dict(data)


def init_workspace_config(workspace_root: Path, overwrite: bool = False) -> Path:
    path = workspace_config_path(workspace_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not overwrite:
        return path
    path.write_text(DEFAULT_CONFIG_TOML, encoding="utf-8")
    return path
