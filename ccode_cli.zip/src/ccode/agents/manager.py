from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

from .prompts import PROMPTS_BY_AGENT


@dataclass
class Agent:
    name: str
    system_prompt: str


class AgentManager:
    def __init__(self, enabled: list[str], default: str):
        self.enabled = [a for a in enabled if a in PROMPTS_BY_AGENT]
        if not self.enabled:
            self.enabled = ["general"]
        self.default = default if default in self.enabled else self.enabled[0]

        self._agents: Dict[str, Agent] = {
            name: Agent(name=name, system_prompt=PROMPTS_BY_AGENT[name])
            for name in self.enabled
        }

    def get(self, name: str) -> Agent:
        if name not in self._agents:
            return self._agents[self.default]
        return self._agents[name]

    def list(self) -> list[str]:
        return list(self._agents.keys())
