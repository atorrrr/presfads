from __future__ import annotations

from pathlib import Path
import json
import os
from typing import Any, Dict, Optional

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.prompt import Prompt, Confirm
from rich.table import Table
from rich.text import Text

from .agents.manager import AgentManager
from .config import AppConfig, init_workspace_config, load_config, workspace_config_path
from .llm.provider import DummyProvider
from .llm.agno_provider import AgnoProvider
from .orchestrator import Orchestrator
from .patching import restore_backup
from .session import SessionState, list_sessions, load_session, save_session
from .workspace import Workspace


def _make_provider(cfg: AppConfig):
    if cfg.model.provider == "dummy":
        return DummyProvider()
    if cfg.model.provider == "agno":
        return AgnoProvider(cfg.model)
    raise RuntimeError(f"Unknown model provider: {cfg.model.provider}")


def run_chat(root: Path, *, session_id: str | None = None) -> None:
    console = Console()
    root = root.resolve()

    # Auto-initialize config if missing to avoid a confusing first-run experience.
    if not workspace_config_path(root).exists():
        init_workspace_config(root, overwrite=False)
        console.print("Created .ccode/config.toml (edit it to set your model).")

    cfg = load_config(root)
    ws = Workspace.from_root(root)
    agents = AgentManager(cfg.agents.enabled, cfg.agents.default)

    provider = _make_provider(cfg)
    orch = Orchestrator(ws, cfg, provider, agents)

    if session_id:
        session = load_session(root, session_id)
        console.print(f"Loaded session [bold]{session.id}[/bold] (created {session.created_at})")
    else:
        session = SessionState.new(root, active_agent=agents.default)
        console.print(f"Started new session [bold]{session.id}[/bold]")

    console.print(Panel.fit(
        Text("ccode chat — type /help for commands", style="bold"),
        subtitle=f"root={root}",
    ))

    def approve(tool_name: str, args: Dict[str, Any]) -> bool:
        if tool_name == "run_command" and cfg.runtime.confirm_commands:
            cmd = args.get("cmd", "")
            console.print(Panel.fit(f"Model requests running command:\n[bold]{cmd}[/bold]", title="Approval required"))
            return Confirm.ask("Allow?", default=False)
        return True

    while True:
        try:
            line = Prompt.ask("[bold cyan]ccode>[/bold cyan]").strip()
        except (KeyboardInterrupt, EOFError):
            console.print("\nExiting.")
            break

        if not line:
            continue

        if line.startswith("/"):
            handled = _handle_command(console, line, ws, orch, session, agents, cfg)
            if handled == "exit":
                break
            continue

        # normal user message
        session.messages.append({"role": "user", "content": line})
        res = orch.run_turn(session, approval_fn=approve)
        if res.assistant_text:
            console.print(Markdown(res.assistant_text))
        if res.new_patches:
            console.print(Panel.fit(f"{len(res.new_patches)} patch(es) proposed. Use /diff to view, /apply to apply.", title="Patches"))
        # autosave lightweight
        save_session(root, session)


def _handle_command(console: Console, line: str, ws: Workspace, orch: Orchestrator, session: SessionState, agents: AgentManager, cfg: AppConfig) -> str | None:
    parts = line.split(maxsplit=2)
    cmd = parts[0].lower()

    if cmd in {"/exit", "/quit"}:
        save_session(ws.root, session)
        return "exit"

    if cmd == "/help":
        console.print(Panel.fit(
            "\n".join([
                "/help                         Show this help",
                "/tree                         Show file tree (truncated)",
                "/add <path>                   Add file to context",
                "/drop <path>                  Remove file from context",
                "/files                        List selected files",
                "/open <path>                  Show file contents (truncated)",
                "/search <query> [glob]        Search in workspace (optional glob)",
                "/agent <name>                 Switch active agent",
                "/agents                       List available agents",
                "/delegate <agent> <task>      Run a sub-agent on a task",
                "/auto <task>                  Planner→Coder→Reviewer pipeline",
                "/status                       Show git status (if repo)",
                "/diff                         Show pending patches",
                "/apply [n]                    Apply all pending patches or patch n",
                "/undo                         Restore last backup",
                "/run <cmd>                    Run a shell command (manual)",
                "/save                         Save session",
                "/sessions                     List saved sessions",
            ]),
            title="Commands",
        ))
        return None

    if cmd == "/tree":
        console.print(Panel(ws.tree(max_entries=200), title="Workspace tree"))
        return None

    if cmd == "/files":
        if not session.selected_files:
            console.print("(no selected files)")
        else:
            t = Table(title="Selected files")
            t.add_column("#", justify="right")
            t.add_column("Path")
            for i, p in enumerate(session.selected_files, start=1):
                t.add_row(str(i), p)
            console.print(t)
        return None

    if cmd == "/add" and len(parts) >= 2:
        path = parts[1]
        # validate exists
        try:
            ws.resolve_rel(path)
        except Exception as e:
            console.print(f"[red]Invalid path:[/red] {e}")
            return None
        if path not in session.selected_files:
            session.selected_files.append(path)
            console.print(f"Added {path}")
        return None

    if cmd == "/drop" and len(parts) >= 2:
        path = parts[1]
        if path in session.selected_files:
            session.selected_files.remove(path)
            console.print(f"Dropped {path}")
        return None

    if cmd == "/open" and len(parts) >= 2:
        path = parts[1]
        try:
            txt = ws.read_text(path, max_bytes=200_000)
            lines = txt.splitlines()
            snippet = "\n".join(lines[:200])
            if len(lines) > 200:
                snippet += f"\n... (truncated; total lines: {len(lines)})"
            console.print(Panel(snippet, title=path))
        except Exception as e:
            console.print(f"[red]Failed to open:[/red] {e}")
        return None

    if cmd == "/search" and len(parts) >= 2:
        query = parts[1]
        glob = parts[2] if len(parts) >= 3 else None
        results = ws.search(query, glob=glob, max_results=30)
        if not results:
            console.print("(no results)")
            return None
        t = Table(title=f"Search results for: {query}")
        t.add_column("Path")
        t.add_column("Line", justify="right")
        t.add_column("Col", justify="right")
        t.add_column("Text")
        for r in results:
            t.add_row(r["path"], str(r["line"]), str(r["col"]), r["text"])
        console.print(t)
        return None

    if cmd == "/agents":
        console.print("Agents: " + ", ".join(agents.list()))
        return None

    if cmd == "/agent" and len(parts) >= 2:
        name = parts[1]
        if name not in agents.list():
            console.print(f"[red]Unknown agent[/red]: {name}")
        else:
            session.active_agent = name
            console.print(f"Active agent set to [bold]{name}[/bold]")
        return None

    if cmd == "/delegate" and len(parts) >= 3:
        agent = parts[1]
        task = parts[2]
        # We'll execute delegation by asking the LLM via the orchestrator's tool (delegate tool),
        # but here we just run a direct sub-turn for convenience.
        console.print(Panel.fit(f"Delegating to [bold]{agent}[/bold]: {task}", title="Delegate"))
        sub_session = SessionState.new(ws.root, active_agent=agent)
        sub_session.selected_files = list(session.selected_files)
        sub_session.messages.append({"role": "user", "content": task})
        # Delegate mode should still ask before commands.
        def approve(tool_name: str, args: Dict[str, Any]) -> bool:
            if tool_name == "run_command" and cfg.runtime.confirm_commands:
                cmd = args.get("cmd", "")
                console.print(Panel.fit(f"Sub-agent requests running command:\n[bold]{cmd}[/bold]", title="Approval required"))
                return Confirm.ask("Allow?", default=False)
            return True
        res = orch.run_turn(sub_session, agent_name=agent, approval_fn=approve, max_steps=6)
        if res.assistant_text:
            console.print(Markdown(res.assistant_text))
        if res.new_patches:
            console.print(Panel.fit(f"{len(res.new_patches)} patch(es) proposed by sub-agent (NOT auto-applied).", title="Patches"))
            # Merge sub-agent patches into main session's pending list
            session.pending_patches.extend(res.new_patches)
        return None

    
    if cmd == "/status":
        import shutil, subprocess
        git = shutil.which("git")
        if not git:
            console.print("(git not found)")
            return None
        try:
            proc = subprocess.run(
                [git, "status", "--porcelain=v1", "-b"],
                cwd=str(ws.root),
                capture_output=True,
                text=True,
                timeout=10,
            )
            out = (proc.stdout or "").strip() or "(clean)"
            console.print(Panel(out, title="git status"))
        except Exception as e:
            console.print(f"[red]git status failed:[/red] {e}")
        return None

    if cmd == "/auto":
        task = line[len("/auto"):].strip()
        if not task:
            console.print("[red]Usage:[/red] /auto <task>")
            return None

        def approve(tool_name: str, args: Dict[str, Any]) -> bool:
            if tool_name == "run_command" and cfg.runtime.confirm_commands:
                cmdtxt = args.get("cmd", "")
                console.print(Panel.fit(f"Agent requests running command:\n[bold]{cmdtxt}[/bold]", title="Approval required"))
                return Confirm.ask("Allow?", default=False)
            return True

        console.print(Panel.fit(task, title="Auto pipeline: task"))

        # 1) Planner
        plan_s = SessionState.new(ws.root, active_agent="planner")
        plan_s.selected_files = list(session.selected_files)
        plan_s.messages.append({"role": "user", "content": task})
        plan = orch.run_turn(plan_s, agent_name="planner", approval_fn=approve, max_steps=6)
        if plan.assistant_text:
            console.print(Panel.fit(Markdown(plan.assistant_text), title="Planner"))

        # 2) Coder (feed plan as extra context)
        coder_prompt = task
        if plan.assistant_text:
            coder_prompt = f"Task:\n{task}\n\nPlanner output:\n{plan.assistant_text}"
        code_s = SessionState.new(ws.root, active_agent="coder")
        code_s.selected_files = list(session.selected_files)
        code_s.messages.append({"role": "user", "content": coder_prompt})
        code = orch.run_turn(code_s, agent_name="coder", approval_fn=approve, max_steps=8)
        if code.assistant_text:
            console.print(Panel.fit(Markdown(code.assistant_text), title="Coder"))
        if code.new_patches:
            session.pending_patches.extend(code.new_patches)
            console.print(Panel.fit(f"{len(code.new_patches)} patch(es) proposed (merged into pending). Use /diff and /apply.", title="Patches"))

        # 3) Reviewer
        if code.new_patches:
            patch_blob = "\n\n".join(p.patch for p in code.new_patches)
            # avoid sending gigantic patch to reviewer
            if len(patch_blob) > 40_000:
                patch_blob = patch_blob[:40_000] + "\n... (truncated)"
            rev_prompt = f"Review the following proposed patches and point out issues or improvements.\n\n{patch_blob}"
        else:
            rev_prompt = f"Review the plan and suggest improvements or risks.\n\n{plan.assistant_text or ''}"
        rev_s = SessionState.new(ws.root, active_agent="reviewer")
        rev_s.selected_files = list(session.selected_files)
        rev_s.messages.append({"role": "user", "content": rev_prompt})
        rev = orch.run_turn(rev_s, agent_name="reviewer", approval_fn=approve, max_steps=6)
        if rev.assistant_text:
            console.print(Panel.fit(Markdown(rev.assistant_text), title="Reviewer"))

        return None
    if cmd == "/diff":
        if not session.pending_patches:
            console.print("(no pending patches)")
            return None
        for i, p in enumerate(session.pending_patches, start=1):
            console.print(Panel(p.patch, title=f"Patch {i}: {p.summary}"))
        return None

    if cmd == "/apply":
        which = None
        if len(parts) >= 2:
            try:
                which = int(parts[1])
            except ValueError:
                console.print("[red]Usage:[/red] /apply [n]")
                return None

        if cfg.runtime.confirm_writes:
            msg = "Apply all pending patches?" if which is None else f"Apply patch {which}?"
            if not Confirm.ask(msg, default=False):
                console.print("Cancelled.")
                return None

        ok, msg = orch.apply_pending_patches(session, which=which)
        console.print(Panel.fit(msg, title="Apply patches", style="green" if ok else "red"))
        save_session(ws.root, session)
        return None

    if cmd == "/undo":
        if not session.last_backup_dir:
            console.print("(no backup recorded)")
            return None
        backup_dir = Path(session.last_backup_dir)
        res = restore_backup(ws.root, backup_dir)
        console.print(Panel.fit(res.message, title="Undo", style="green" if res.ok else "red"))
        return None

    if cmd == "/run" and len(parts) >= 2:
        cmdline = line[len("/run "):].strip()
        if cfg.runtime.confirm_commands and not Confirm.ask(f"Run command: {cmdline} ?", default=False):
            console.print("Cancelled.")
            return None
        out = orch._run_command(cmdline)
        console.print(Panel.fit(json.dumps(out, indent=2, ensure_ascii=False), title="Command output"))
        return None

    if cmd == "/save":
        path = save_session(ws.root, session)
        console.print(f"Saved session to {path}")
        return None

    if cmd == "/sessions":
        sids = list_sessions(ws.root)
        if not sids:
            console.print("(no sessions)")
        else:
            console.print("Sessions: " + ", ".join(sids))
        return None

    console.print(f"[red]Unknown command[/red]: {cmd}. Type /help.")
    return None
