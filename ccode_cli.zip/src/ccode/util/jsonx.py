from __future__ import annotations
import json
from typing import Any, Tuple


def try_parse_json(s: str) -> Tuple[bool, Any | None, str | None]:
    """Returns (ok, value, error_message)."""
    try:
        return True, json.loads(s), None
    except Exception as e:
        return False, None, str(e)
