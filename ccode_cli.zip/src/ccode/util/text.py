from __future__ import annotations
import re
from typing import List, Tuple


_TAG_RE_CACHE: dict[str, re.Pattern[str]] = {}


def extract_tag_blocks(text: str, tag: str) -> Tuple[str, List[str]]:
    """
    Extract blocks like <tag>...</tag>.

    Returns: (text_without_blocks, [block_contents...])
    """
    if tag not in _TAG_RE_CACHE:
        _TAG_RE_CACHE[tag] = re.compile(
            rf"<{re.escape(tag)}>(.*?)</{re.escape(tag)}>",
            flags=re.DOTALL | re.IGNORECASE,
        )
    rx = _TAG_RE_CACHE[tag]

    blocks: List[str] = []
    def _repl(m: re.Match[str]) -> str:
        blocks.append(m.group(1).strip())
        return ""  # remove block
    cleaned = rx.sub(_repl, text)
    return cleaned.strip(), blocks


def strip_code_fences(s: str) -> str:
    s = s.strip()
    if s.startswith("```") and s.endswith("```"):
        lines = s.splitlines()
        if len(lines) >= 2:
            return "\n".join(lines[1:-1]).strip()
    return s
