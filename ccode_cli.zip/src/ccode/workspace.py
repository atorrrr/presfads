from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import os
import shutil
import subprocess
import time
from typing import Iterable, List, Optional, Tuple

try:
    import pathspec
except Exception:  # pragma: no cover
    pathspec = None


DEFAULT_IGNORE = [
    ".git/",
    ".ccode/",
    "__pycache__/",
    "*.pyc",
    "node_modules/",
    "dist/",
    "build/",
    ".venv/",
    "venv/",
    ".mypy_cache/",
    ".pytest_cache/",
    ".DS_Store",
]


def _is_binary_bytes(b: bytes) -> bool:
    # Heuristic: if there are NUL bytes, treat as binary
    return b"\x00" in b


@dataclass
class Workspace:
    root: Path
    ignore_patterns: list[str]

    def __post_init__(self) -> None:
        self.root = self.root.resolve()
        if not self.root.exists():
            raise FileNotFoundError(f"Workspace root not found: {self.root}")

        self._spec = None
        if pathspec is not None:
            self._spec = pathspec.PathSpec.from_lines("gitwildmatch", self.ignore_patterns)

    @staticmethod
    def from_root(root: Path) -> "Workspace":
        patterns: list[str] = list(DEFAULT_IGNORE)
        # read .ccodeignore and .gitignore if present
        for fname in [".ccodeignore", ".gitignore"]:
            p = root / fname
            if p.exists():
                for line in p.read_text(encoding="utf-8", errors="ignore").splitlines():
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    patterns.append(line)
        return Workspace(root=root, ignore_patterns=patterns)

    def resolve_rel(self, rel: str) -> Path:
        """Resolve a relative path within workspace, preventing path traversal."""
        p = (self.root / rel).resolve()
        try:
            p.relative_to(self.root)
        except Exception:
            raise ValueError(f"Path escapes workspace: {rel}")
        return p

    def is_ignored(self, rel_path: str) -> bool:
        rel_path = rel_path.replace(os.sep, "/")
        if self._spec is not None:
            return self._spec.match_file(rel_path)
        # fallback: naive glob-ish matching
        for pat in self.ignore_patterns:
            pat = pat.strip()
            if not pat:
                continue
            # directory patterns
            if pat.endswith("/") and rel_path.startswith(pat):
                return True
            if rel_path == pat:
                return True
        return False

    def list_files(self, limit: int | None = None) -> list[str]:
        out: list[str] = []
        for dirpath, dirnames, filenames in os.walk(self.root):
            rel_dir = os.path.relpath(dirpath, self.root).replace(os.sep, "/")
            if rel_dir == ".":
                rel_dir = ""
            # prune ignored directories
            pruned: list[str] = []
            for d in list(dirnames):
                rel = f"{rel_dir}{d}/" if rel_dir else f"{d}/"
                if self.is_ignored(rel):
                    pruned.append(d)
            for d in pruned:
                dirnames.remove(d)

            for f in filenames:
                rel = f"{rel_dir}{f}" if rel_dir else f
                if self.is_ignored(rel):
                    continue
                out.append(rel)
                if limit is not None and len(out) >= limit:
                    return sorted(out)
        return sorted(out)

    def read_text(self, rel: str, max_bytes: int = 200_000) -> str:
        p = self.resolve_rel(rel)
        if not p.exists():
            raise FileNotFoundError(rel)
        data = p.read_bytes()
        if _is_binary_bytes(data[:4096]):
            raise ValueError(f"Binary file: {rel}")
        if len(data) > max_bytes:
            data = data[:max_bytes]
        return data.decode("utf-8", errors="replace")

    def file_stats(self, rel: str) -> dict:
        p = self.resolve_rel(rel)
        st = p.stat()
        return {
            "path": rel,
            "size": st.st_size,
            "mtime": st.st_mtime,
        }

    def tree(self, max_entries: int = 200) -> str:
        files = self.list_files(limit=max_entries)
        if not files:
            return "(no files found)"
        lines = []
        for f in files:
            lines.append(f)
        if len(files) >= max_entries:
            lines.append(f"... (truncated at {max_entries} files)")
        return "\n".join(lines)

    def search(self, query: str, glob: str | None = None, max_results: int = 50) -> list[dict]:
        """
        Search text in workspace. Uses ripgrep if available; else fallback to python scanning.
        Returns list of {path, line, col, text}.
        """
        rg = shutil.which("rg")
        if rg:
            cmd = [rg, "--with-filename", "--line-number", "--column", "--color", "never", query, str(self.root)]
            if glob:
                cmd.extend(["-g", glob])
            try:
                proc = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
                out = []
                for line in proc.stdout.splitlines():
                    # path:line:col:text
                    parts = line.split(":", 3)
                    if len(parts) < 4:
                        continue
                    path, ln, col, txt = parts
                    rel = os.path.relpath(path, self.root).replace(os.sep, "/")
                    if self.is_ignored(rel):
                        continue
                    out.append({"path": rel, "line": int(ln), "col": int(col), "text": txt})
                    if len(out) >= max_results:
                        break
                return out
            except Exception:
                pass

        # fallback scan
        results: list[dict] = []
        files = self.list_files()
        for rel in files:
            if glob:
                # very rough glob filtering
                from fnmatch import fnmatch
                if not fnmatch(rel, glob):
                    continue
            try:
                txt = self.read_text(rel, max_bytes=400_000)
            except Exception:
                continue
            for i, line in enumerate(txt.splitlines(), start=1):
                idx = line.find(query)
                if idx != -1:
                    results.append({"path": rel, "line": i, "col": idx + 1, "text": line[:400]})
                    if len(results) >= max_results:
                        return results
        return results
