from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json
import subprocess
import shlex
from typing import Any, Callable, Dict, List, Optional, Tuple

from .agents.manager import AgentManager
from .config import AppConfig
from .llm.provider import LLMProvider
from .patching import apply_patch
from .session import PendingPatch, SessionState
from .tools import ToolRegistry, build_default_tools
from .util.text import extract_tag_blocks, strip_code_fences
from .util.jsonx import try_parse_json
from .workspace import Workspace


ApprovalFn = Callable[[str, Dict[str, Any]], bool]


@dataclass
class TurnResult:
    assistant_text: str
    new_patches: list[PendingPatch]
    tool_calls: list[dict]
    raw_assistant: str


def _approx_token_budget(chars: int) -> int:
    # Rough heuristic; avoids external tokenizers.
    return max(1, chars // 4)


def build_context(workspace: Workspace, selected_files: list[str], max_chars: int) -> str:
    parts: list[str] = []
    parts.append(f"Workspace root: {workspace.root}")
    parts.append("")
    parts.append("Workspace file tree (truncated):")
    parts.append(workspace.tree(max_entries=200))
    parts.append("")
    if selected_files:
        parts.append("Selected files included below:")
    else:
        parts.append("No selected files. You can ask to read files via tools or use /add in the REPL.")
    parts.append("")

    remaining = max_chars
    def add_block(title: str, body: str) -> None:
        nonlocal remaining
        block = f"---\n{title}\n---\n{body.strip()}\n"
        if len(block) <= remaining:
            parts.append(block)
            remaining -= len(block)
        else:
            # add truncated
            truncated = block[: max(0, remaining - 50)]
            parts.append(truncated + "\n... (context truncated)\n")
            remaining = 0

    for rel in selected_files:
        if remaining <= 0:
            break
        try:
            content = workspace.read_text(rel, max_bytes=250_000)
        except Exception as e:
            add_block(f"[FILE] {rel}", f"(unreadable: {e})")
            continue
        # cap per file a bit
        lines = content.splitlines()
        snippet = "\n".join(lines[:600])
        if len(lines) > 600:
            snippet += f"\n... (truncated; total lines: {len(lines)})"
        add_block(f"[FILE] {rel}", snippet)

    ctx = "\n".join(parts).strip()
    # final hard cap
    if len(ctx) > max_chars:
        ctx = ctx[:max_chars] + "\n... (context truncated)"
    return ctx


def parse_tool_blocks(blocks: list[str]) -> tuple[list[dict], list[str]]:
    tool_calls: list[dict] = []
    errors: list[str] = []
    for b in blocks:
        b2 = strip_code_fences(b)
        ok, val, err = try_parse_json(b2)
        if not ok:
            errors.append(f"Failed to parse <tool> JSON: {err}\nContent: {b2[:200]}")
            continue
        if isinstance(val, dict):
            tool_calls.append(val)
        elif isinstance(val, list):
            for item in val:
                if isinstance(item, dict):
                    tool_calls.append(item)
                else:
                    errors.append(f"Ignoring non-dict tool call item: {item!r}")
        else:
            errors.append(f"Ignoring <tool> JSON (expected object or list): {type(val)}")
    return tool_calls, errors


class Orchestrator:
    def __init__(self, workspace: Workspace, config: AppConfig, provider: LLMProvider, agents: AgentManager):
        self.workspace = workspace
        self.config = config
        self.provider = provider
        self.agents = agents

    def _run_command(self, cmd: str) -> dict:
        # Runs via shell for user convenience; gated by approval.
        try:
            proc = subprocess.run(
                cmd,
                cwd=str(self.workspace.root),
                shell=True,
                capture_output=True,
                text=True,
                timeout=60,
            )
            out = (proc.stdout or "")[-8000:]
            err = (proc.stderr or "")[-8000:]
            return {
                "cmd": cmd,
                "returncode": proc.returncode,
                "stdout": out,
                "stderr": err,
            }
        except Exception as e:
            return {"cmd": cmd, "error": str(e)}

    def _delegate(self, parent_session: SessionState, agent: str, task: str, approval_fn: ApprovalFn | None, depth: int) -> str:
        if depth >= 2:
            return f"(delegate blocked: max depth reached while trying to delegate to {agent})"
        # Run a mini-session for the sub-agent.
        sub = SessionState.new(Path(parent_session.workspace_root), active_agent=agent)
        sub.selected_files = list(parent_session.selected_files)

        # Add the task as user message.
        sub.messages.append({"role": "user", "content": task})

        # Run one turn with tool loop enabled.
        res = self.run_turn(sub, agent_name=agent, approval_fn=approval_fn, max_steps=6, _delegate_depth=depth + 1)
        txt = res.assistant_text.strip()
        if res.new_patches:
            txt += "\n\n(Sub-agent also proposed patches; they were NOT auto-applied.)"
        return txt

    def run_turn(
        self,
        session: SessionState,
        *,
        agent_name: str | None = None,
        approval_fn: ApprovalFn | None = None,
        max_steps: int = 8,
        _delegate_depth: int = 0,
    ) -> TurnResult:
        agent = self.agents.get(agent_name or session.active_agent)
        session.active_agent = agent.name

        # Build tool registry with closures.
        def delegate_fn(agent_name: str, task: str) -> str:
            return self._delegate(session, agent_name, task, approval_fn, _delegate_depth)

        tools = build_default_tools(
            self.workspace,
            run_command_fn=self._run_command,
            delegate_fn=delegate_fn,
        )

        tool_list = "\n".join([f"- {s.name}: {s.description}" for s in tools.list_specs()])

        # The system prompt includes dynamic workspace context (truncated).
        ctx = build_context(self.workspace, session.selected_files, max_chars=self.config.runtime.context_max_chars)
        system_prompt = (agent.system_prompt + "\n\n" + "Available tools:\n" + tool_list + "\n\n" + "Current workspace context:\n" + ctx)

        new_patches: list[PendingPatch] = []
        all_tool_calls: list[dict] = []

        raw_assistant = ""
        assistant_text_final = ""

        for step in range(max_steps):
            raw = self.provider.chat(system_prompt=system_prompt, messages=session.messages, tools=None)
            raw_assistant = raw

            # Extract tool blocks and patch blocks.
            cleaned1, tool_blocks = extract_tag_blocks(raw, "tool")
            cleaned2, patch_blocks = extract_tag_blocks(cleaned1, "patch")
            cleaned_text = cleaned2.strip()

            # Store assistant message (without tool/patch blocks) to history.
            if cleaned_text:
                session.messages.append({"role": "assistant", "content": cleaned_text})
                assistant_text_final = cleaned_text

            # Store patches as pending
            for pb in patch_blocks:
                pid = f"patch_{len(session.pending_patches) + len(new_patches) + 1}"
                summary = (cleaned_text.splitlines()[0][:80] if cleaned_text else "Patch proposed")
                pp = PendingPatch(
                    id=pid,
                    created_at=session.created_at,
                    agent=agent.name,
                    summary=summary,
                    patch=pb.strip(),
                )
                new_patches.append(pp)

            # Parse tool calls
            tool_calls, parse_errors = parse_tool_blocks(tool_blocks)
            if parse_errors:
                err_msg = "\n".join(parse_errors)
                session.messages.append({"role": "assistant", "content": f"(Tool parse errors)\n{err_msg}"})
                assistant_text_final = assistant_text_final or err_msg

            if not tool_calls:
                break

            # Execute tool calls and add results as tool messages.
            for call in tool_calls:
                name = str(call.get("name", ""))
                args = call.get("args", {}) or {}
                all_tool_calls.append({"name": name, "args": args})

                spec = tools.spec(name)
                if spec is None:
                    session.messages.append({"role": "tool", "content": json.dumps({"name": name, "error": "unknown tool"})})
                    continue

                if spec.requires_approval:
                    if approval_fn is None or not approval_fn(name, args):
                        session.messages.append({"role": "tool", "content": json.dumps({"name": name, "args": args, "error": "denied by user"})})
                        continue

                try:
                    result = tools.call(name, args)
                    session.messages.append({"role": "tool", "content": json.dumps({"name": name, "args": args, "result": result}, ensure_ascii=False)})
                except Exception as e:
                    session.messages.append({"role": "tool", "content": json.dumps({"name": name, "args": args, "error": str(e)}, ensure_ascii=False)})

        # Persist pending patches onto session
        if new_patches:
            session.pending_patches.extend(new_patches)

        return TurnResult(
            assistant_text=assistant_text_final,
            new_patches=new_patches,
            tool_calls=all_tool_calls,
            raw_assistant=raw_assistant,
        )

    def apply_pending_patches(self, session: SessionState, *, which: int | None = None) -> tuple[bool, str]:
        if not session.pending_patches:
            return False, "No pending patches to apply."

        patches_to_apply = session.pending_patches
        if which is not None:
            idx = which - 1
            if idx < 0 or idx >= len(session.pending_patches):
                return False, f"Patch index out of range: {which}"
            patches_to_apply = [session.pending_patches[idx]]

        combined = "\n\n".join(p.patch for p in patches_to_apply)
        res = apply_patch(self.workspace.root, combined)
        if res.ok:
            # remove applied patches
            if which is None:
                session.pending_patches.clear()
            else:
                # remove that specific one
                del session.pending_patches[which - 1]
            if res.backup_dir:
                session.last_backup_dir = str(res.backup_dir)
            return True, res.message
        else:
            if res.backup_dir:
                session.last_backup_dir = str(res.backup_dir)
            return False, res.message
