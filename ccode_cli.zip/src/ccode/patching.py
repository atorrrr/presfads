from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import os
import re
import shutil
import subprocess
import time
from typing import Iterable, Set


_FILE_RX = re.compile(r"^\+\+\+\s+b/(.+)$", re.MULTILINE)
_FILE_RX2 = re.compile(r"^\+\+\+\s+(.+)$", re.MULTILINE)


def touched_files_from_patch(patch_text: str) -> Set[str]:
    """Best-effort extraction of file paths touched by a unified diff."""
    files = set()
    for m in _FILE_RX.finditer(patch_text):
        files.add(m.group(1).strip())
    if not files:
        for m in _FILE_RX2.finditer(patch_text):
            p = m.group(1).strip()
            if p.startswith("b/"):
                p = p[2:]
            if p != "/dev/null":
                files.add(p)
    # normalize
    norm = set()
    for f in files:
        f = f.replace("\\", "/")
        f = f.lstrip("./")
        norm.add(f)
    return norm


@dataclass
class ApplyResult:
    ok: bool
    message: str
    backup_dir: Path | None = None
    method: str | None = None


def _safe_relpath(root: Path, rel: str) -> Path:
    p = (root / rel).resolve()
    p.relative_to(root)  # raises if escapes
    return p


def make_backup(root: Path, rel_files: Iterable[str]) -> Path:
    ts = time.strftime("%Y%m%d-%H%M%S")
    backup_dir = root / ".ccode" / "backups" / ts
    backup_dir.mkdir(parents=True, exist_ok=True)

    for rel in rel_files:
        try:
            src = _safe_relpath(root, rel)
        except Exception:
            continue
        if not src.exists():
            continue
        dst = backup_dir / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
    return backup_dir


def restore_backup(root: Path, backup_dir: Path) -> ApplyResult:
    if not backup_dir.exists():
        return ApplyResult(ok=False, message=f"Backup dir not found: {backup_dir}")
    restored = 0
    for path in backup_dir.rglob("*"):
        if path.is_dir():
            continue
        rel = os.path.relpath(path, backup_dir).replace(os.sep, "/")
        dst = root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, dst)
        restored += 1
    return ApplyResult(ok=True, message=f"Restored {restored} file(s) from backup {backup_dir}", backup_dir=backup_dir, method="restore")


def _write_patch_tmp(root: Path, patch_text: str) -> Path:
    tmp_dir = root / ".ccode" / "tmp"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    patch_path = tmp_dir / "pending.patch"
    patch_path.write_text(patch_text, encoding="utf-8")
    return patch_path


def _validate_patch_paths(root: Path, patch_text: str) -> ApplyResult | None:
    touched = touched_files_from_patch(patch_text)
    for rel in touched:
        try:
            _safe_relpath(root, rel)
        except Exception:
            return ApplyResult(ok=False, message=f"Unsafe patch path escapes workspace: {rel}")
    return None


def apply_patch_with_git(root: Path, patch_text: str) -> ApplyResult:
    git = shutil.which("git")
    if not git:
        return ApplyResult(ok=False, message="git not found on PATH; cannot use git apply", method="git")

    unsafe = _validate_patch_paths(root, patch_text)
    if unsafe:
        unsafe.method = "git"
        return unsafe

    patch_path = _write_patch_tmp(root, patch_text)
    touched = touched_files_from_patch(patch_text)
    backup_dir = make_backup(root, touched)

    try:
        proc = subprocess.run(
            [git, "apply", "--recount", "--whitespace=nowarn", str(patch_path)],
            cwd=str(root),
            capture_output=True,
            text=True,
            timeout=30,
        )
    except Exception as e:
        return ApplyResult(ok=False, message=f"git apply failed to run: {e}", backup_dir=backup_dir, method="git")

    if proc.returncode != 0:
        msg = (proc.stderr or proc.stdout or "").strip()
        return ApplyResult(ok=False, message=f"git apply failed: {msg}", backup_dir=backup_dir, method="git")

    return ApplyResult(ok=True, message="Patch applied successfully (git apply).", backup_dir=backup_dir, method="git")


def apply_patch_with_patch_cmd(root: Path, patch_text: str) -> ApplyResult:
    patch = shutil.which("patch")
    if not patch:
        return ApplyResult(ok=False, message="patch command not found on PATH", method="patch")

    unsafe = _validate_patch_paths(root, patch_text)
    if unsafe:
        unsafe.method = "patch"
        return unsafe

    patch_path = _write_patch_tmp(root, patch_text)
    touched = touched_files_from_patch(patch_text)
    backup_dir = make_backup(root, touched)

    # Try -p1 then -p0 for robustness.
    for p_level in (1, 0):
        try:
            proc = subprocess.run(
                [patch, f"-p{p_level}", "--batch", "--forward", "--input", str(patch_path)],
                cwd=str(root),
                capture_output=True,
                text=True,
                timeout=30,
            )
        except Exception as e:
            return ApplyResult(ok=False, message=f"patch failed to run: {e}", backup_dir=backup_dir, method="patch")

        if proc.returncode == 0:
            return ApplyResult(ok=True, message=f"Patch applied successfully (patch -p{p_level}).", backup_dir=backup_dir, method="patch")

    msg = ((proc.stderr or "") + "\n" + (proc.stdout or "")).strip()
    return ApplyResult(ok=False, message=f"patch failed: {msg}", backup_dir=backup_dir, method="patch")


def apply_patch(root: Path, patch_text: str) -> ApplyResult:
    """Try git apply, then patch."""
    res = apply_patch_with_git(root, patch_text)
    if res.ok:
        return res
    # If git isn't available or failed, try patch.
    res2 = apply_patch_with_patch_cmd(root, patch_text)
    if res2.ok:
        return res2
    # Return the git failure by default if git existed; otherwise patch failure.
    if res.method == "git" and "git not found" not in res.message:
        return res
    return res2
